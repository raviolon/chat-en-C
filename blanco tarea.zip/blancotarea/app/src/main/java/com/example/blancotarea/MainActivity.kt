package com.example.blancotarea


import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val email = findViewById<EditText>(R.id.editTextText)
        val password = findViewById<EditText>(R.id.editTextText2)
        val boton = findViewById<Button>(R.id.button)

        val emailFijo = "luceroariel555@gmail.com"
        val passwordFijo = "1234"

        boton.setOnClickListener {
            val textoEmail = email.text.toString()
            val textoPassword = password.text.toString()

            if (textoEmail.isEmpty() || textoPassword.isEmpty()) {
                Toast.makeText(this, "Faltan datos", Toast.LENGTH_SHORT).show()
            } else if (textoEmail == emailFijo && textoPassword == passwordFijo) {
                Toast.makeText(this, "Login correcto", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Datos incorrectos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}